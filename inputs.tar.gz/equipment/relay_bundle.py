"""Bind the 2.8 relay (praxis-relay 8ba23b8 on base 1.2.0: quota failover) into every desktop package.

Same contract as the 2.7.2 binder (relay120-bundle), with candidate passports: one source archive for all
platforms, base commit = the product's pinned 1.2.0 release, native binary per platform.
"""
from pathlib import Path
import hashlib, json, tarfile


def bind(refresh, source, platform, arch):
    from portable_zip import Entry
    key = {'windows': 'windows-x86_64', 'debian': 'linux-x86_64', 'fedora': 'linux-x86_64',
           'macos': 'macos-' + arch}[platform]
    pin = json.loads((source / 'desk/localharness/relay-release.json').read_bytes())
    entries = {}
    with tarfile.open(Path(__file__).with_name('relay284-bundle.tar.gz')) as z:
        manifest = json.load(z.extractfile('MANIFEST.json'))
        expected = manifest['platforms'][key]
        for name, row in expected.items():
            assert Path(name).name == name and row['mode'] in (0o644, 0o755)
            item = z.getmember(key + '/' + name); assert item.isfile() and item.mode == row['mode']
            data = z.extractfile(item).read()
            assert len(data) == row['size'] and hashlib.sha256(data).hexdigest() == row['sha256'], name
            entries[name] = Entry(data, '100755' if row['mode'] == 0o755 else '100644')
    passport = json.loads(entries['BUILD-PASSPORT.json'].data)
    assert passport['candidate'] is True and passport['native_platform'] == key
    assert passport['version'] == pin['version'] and passport['base_commit'] == pin['source_commit']
    assert passport['source_commit'] == manifest['source_commit']
    source_sha = hashlib.sha256(entries['source.zip'].data).hexdigest()
    assert passport['source_archive_sha256'] == manifest['source_archive_sha256'] == source_sha
    assert passport['binary']['sha256'] == hashlib.sha256(entries[passport['binary']['name']].data).hexdigest()
    original = refresh._metadata

    def metadata(package, *args, **kwargs):
        package.replace_tree('Helene/relay-product/', entries)
        value = package.value('python-app.json')
        if 'native_inputs' in value:
            value['native_inputs']['relay'] = True
        value['bundled_relay_source_commit'] = passport['source_commit']
        package.put_value('python-app.json', value)
        return original(package, *args, **kwargs)

    refresh._metadata = metadata
