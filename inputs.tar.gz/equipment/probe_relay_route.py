from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from types import SimpleNamespace
import argparse
import hashlib
import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time


class RefusingProxy(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def do_CONNECT(self):
        self.server.requests.append({'method': self.command, 'target': self.path,
                                     'authorization': 'Authorization' in self.headers,
                                     'cookie': 'Cookie' in self.headers})
        self.send_error(502)


def probe(source, binary, log):
    sys.path.insert(0, str(source))
    from localharness import python_relay, relay_network

    with tempfile.TemporaryDirectory(dir=log.parent) as temporary:
        tree = Path(temporary)
        with socket.socket() as listener:
            listener.bind(('127.0.0.1', 0))
            port = listener.getsockname()[1]
        proxy = ThreadingHTTPServer(('127.0.0.1', 0), RefusingProxy)
        proxy.requests = []
        thread = threading.Thread(target=proxy.serve_forever, daemon=True)
        thread.start()
        route = {'proxy': {'mode': 'proxy', 'protocol': 'http', 'host': '127.0.0.1', 'port': proxy.server_port}}
        env = dict(os.environ, **relay_network.environment(route))
        env.update(RELAY_AUTH_DIR=str(tree / 'relay/local_auth'), RELAY_PORT=str(port), RELAY_LOCAL='1',
                   RELAY_API_KEY='fixture-relay-client-key', RELAY_LOG_DIR=str(tree / 'logs'),
                   RELAY_CODEX_VERSION='0.163.0', RELAY_MODEL_DISCOVERY='off')
        agent = SimpleNamespace(tree=tree)
        try:
            with log.open('xb') as output:
                process = subprocess.Popen([str(binary), 'serve', '--headless'], cwd=tree, env=env,
                                           stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT,
                                           creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
                try:
                    end = time.monotonic() + 35
                    while time.monotonic() < end:
                        assert process.poll() is None, 'Relay exited before readiness'
                        try:
                            python_relay.control(agent, 'status', timeout_sec=1)
                        except (OSError, ValueError):
                            time.sleep(.15)
                            continue
                        break
                    else:
                        raise TimeoutError('Relay did not become ready')
                    response = python_relay.control(agent, 'network_check')
                finally:
                    if process.poll() is None:
                        try:
                            python_relay.control(agent, 'stop', timeout_sec=1)
                            process.wait(timeout=4)
                        except (OSError, ValueError, subprocess.TimeoutExpired):
                            process.terminate()
                            process.wait(timeout=5)
        finally:
            proxy.shutdown()
            proxy.server_close()
            thread.join(timeout=2)
        expected = {'method': 'CONNECT', 'target': 'chatgpt.com:443', 'authorization': False, 'cookie': False}
        assert response == {'ok': False, 'error_code': 'transport', 'generation_sent': False}, response
        assert proxy.requests == [expected], proxy.requests
        return {'passed': True, 'relay_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
                'response': response, 'proxy_requests': proxy.requests}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('source', type=Path)
    parser.add_argument('binary', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    result = probe(args.source.resolve(), args.binary.resolve(), args.output.with_suffix('.log').resolve())
    args.output.write_text(json.dumps(result, indent=2), encoding='utf8')
    print(json.dumps(result))
